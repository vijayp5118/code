$FunctionURL="https://powershellfunctionapp120030.azurewebsites.net/api/storagefunction?code=D1C77FiXuFY1QaAGROraQEQaxaz/8l5Zl7yTRoIuNzY3wB8fMbYi7Q=="

$Response=Invoke-RestMethod -Uri $FunctionURL

$Response