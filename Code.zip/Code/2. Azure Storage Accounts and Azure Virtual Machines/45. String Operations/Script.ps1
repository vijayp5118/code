
$ServerName="dbserver36646"

'Does the Server Name contain db = ' + $ServerName.Contains("db")

'Does the Server Name end with db = ' + $ServerName.EndsWith("db")

'The position of 3 in the Server Name is = ' + $ServerName.IndexOf('3')